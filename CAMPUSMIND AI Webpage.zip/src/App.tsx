import type { ReactNode } from "react"

/* EDIT ME: all page details live here. Bracketed text = placeholder. */
const INFO = {
  app: "CAMPUSMIND AI",
  tagline: "The multi-persona AI study companion for university students.",
  intro: "Five specialised tutors, a memory that knows who you are, and answers grounded in your own lectures. Built natively for Android with Kotlin and Jetpack Compose.",
  hackathon: "ASPIRE PAKISTAN x iCODEGURU",
  date: "OCTOBER 04, 2026",
  team: "Team Aplha",
  members: ["M. Ali Qadeer (Leader)", "Aazan Khan", "Juvariya Qadeer", "M. Hassam Murtaza"],
  problem: {
    headline: "Coursework spans many domains, and no single tool keeps up.",
    stats: [
      { n: "Scattered", t: "Debugging code, drafting essays, planning revision and decoding lecture notes all need different tools." },
      { n: "Forgetful", t: "Generic chatbots ask who you are and what you study every single time." },
      { n: "Ungrounded", t: "Answers rarely come from your actual course material, and can expose instructor details." },
    ],
  },
  solution: {
    headline: "One Android app that tutors, remembers and stays on topic.",
    body: "CampusMind AI consolidates your academic needs into a single, personalised assistant powered by Gemini.",
    points: ["Five purpose-built personas", "Automatic student memory", "Lecture Q&A with strict privacy"],
  },
  features: [
    { k: "01", t: "Five academic personas", d: "Campus Assistant, Python Tutor, Writing Coach, Study Planner and Research Helper, each with its own guidance style." },
    { k: "02", t: "Student memory layer", d: "Detects your name, major, year and university from natural chat, then personalises every reply." },
    { k: "03", t: "Lecture notes Q&A", d: "Retrieval over course lectures or your pasted notes, with instructor names and contact details never revealed." },
    { k: "04", t: "Productivity tools", d: "Gemini model switcher, read-aloud, code copy buttons, light and dark themes, chat export and live stats." },
  ],
  personas: [
    ["Campus Assistant", "Study methods and university life"],
    ["Python Tutor", "Complete, runnable code with explanations"],
    ["Writing Coach", "Clarity, thesis and argument structure"],
    ["Study Planner", "Exam schedules and time blocking"],
    ["Research Helper", "Sources and literature reviews"],
  ],
  stack: [
    { g: "Platform", i: ["Android · Min SDK 26", "Target SDK 36"] },
    { g: "UI", i: ["Kotlin 2.2", "Jetpack Compose + Material 3"] },
    { g: "Architecture", i: ["MVVM + StateFlow", "OkHttp 4.12", "SharedPreferences JSON"] },
    { g: "AI", i: ["Gemini 3.5 Flash", "Gemini 3.1 Pro", "Gemini 3.1 Flash Lite"] },
  ],
  differentiator: "A deterministic memory layer injects your student context into every turn, while document mode strictly protects instructor identities.",
  cta: {
    headline: "Try it on your phone.",
    steps: ["Download the APK using the button below", "Allow install from this source", "Open CampusMind AI and pick a persona"],
    link: "#",
    contact: "[team@email.com]",
  },
}

/* ------------------------------ UI bits ------------------------------ */

const Eyebrow = ({ children, dark = false }: { children: ReactNode; dark?: boolean }) => (
  <div className={`font-mono text-sm uppercase tracking-[0.2em] ${dark ? "text-ink" : "text-lime"}`}>{children}</div>
)

const H = ({ children, className = "" }: { children: ReactNode; className?: string }) => (
  <h2 className={`font-display font-bold leading-[1.05] tracking-[-0.03em] text-[clamp(2rem,5vw,3.75rem)] ${className}`}>{children}</h2>
)

const Section = ({ id, children, className = "" }: { id?: string; children: ReactNode; className?: string }) => (
  <section id={id} className={`px-6 py-24 md:px-10 lg:py-32 ${className}`}>
    <div className="mx-auto max-w-6xl">{children}</div>
  </section>
)

const Phone = ({ children, tilt = 0, label }: { children: ReactNode; tilt?: number; label?: string }) => (
  <div className="flex flex-col items-center gap-5">
    <div
      className="relative h-[640px] w-[310px] shrink-0 overflow-hidden rounded-[52px] border-[10px] border-[#0f0930] bg-ink shadow-[0_40px_80px_-20px_rgba(0,0,0,0.6)]"
      style={{ transform: `rotate(${tilt}deg)` }}
    >
      <div className="absolute left-1/2 top-3 h-[22px] w-[90px] -translate-x-1/2 rounded-full bg-[#0f0930]" />
      <div className="flex h-full flex-col px-5 pb-6 pt-14">{children}</div>
    </div>
    {label && <div className="font-mono text-base text-haze">{label}</div>}
  </div>
)

const ScreenPersonas = () => (
  <>
    <div className="text-[13px] text-haze">Choose your tutor</div>
    <div className="mt-1 font-display text-[28px] font-bold leading-tight">Who do you need today?</div>
    <div className="mt-6 flex flex-col gap-2.5">
      {[
        ["Campus Assistant", "Study methods, campus life", true],
        ["Python Tutor", "Runnable code, clear syntax", false],
        ["Writing Coach", "Thesis and argument", false],
        ["Study Planner", "Exam schedules", false],
        ["Research Helper", "Sources and reviews", false],
      ].map(([t, d, on]) => (
        <div key={t as string} className={`rounded-2xl p-3.5 ${on ? "bg-lime text-ink" : "bg-ink-2"}`}>
          <div className="text-[15px] font-semibold">{t}</div>
          <div className={`text-[13px] ${on ? "text-ink/70" : "text-haze"}`}>{d}</div>
        </div>
      ))}
    </div>
    <div className="mt-auto flex items-center justify-between rounded-full bg-ink-2 px-4 py-2.5 text-[13px] text-haze">
      Model <span className="font-mono text-lime">Gemini 3.5 Flash</span>
    </div>
  </>
)

const ScreenChat = () => (
  <>
    <div className="flex items-center gap-2">
      <div className="h-8 w-8 rounded-full bg-lime" />
      <div className="font-semibold">Python Tutor</div>
    </div>
    <div className="mt-5 flex flex-col gap-3 text-[14px] leading-snug">
      <div className="max-w-[85%] self-end rounded-2xl rounded-br-sm bg-ink-3 p-3">How do I reverse a list in Python?</div>
      <div className="max-w-[92%] rounded-2xl rounded-bl-sm bg-ink-2 p-3">
        Use slicing for a quick copy:
        <div className="mt-2 rounded-lg bg-ink p-2.5 font-mono text-[12px] text-lime">
          nums = [1, 2, 3]
          <br />
          print(nums[::-1])
        </div>
        <div className="mt-2 text-[12px] text-haze">Copy · Read aloud</div>
      </div>
    </div>
    <div className="mt-auto flex items-center gap-2 rounded-full bg-ink-2 px-4 py-3 text-[14px] text-haze">
      Ask anything
      <div className="ml-auto h-6 w-6 rounded-full bg-lime" />
    </div>
  </>
)

const ScreenMemory = () => (
  <>
    <div className="font-display text-[28px] font-bold">Student memory</div>
    <div className="text-[14px] text-haze">Picked up from your chats</div>
    <div className="mt-6 flex flex-col gap-2.5">
      {[
        ["Name", "Aazan"],
        ["Major", "Computer Science"],
        ["Year", "Sophomore"],
        ["University", "IIUI"],
      ].map(([k, v]) => (
        <div key={k} className="flex items-center justify-between rounded-2xl bg-ink-2 px-4 py-3">
          <span className="text-[13px] text-haze">{k}</span>
          <span className="text-[15px] font-semibold">{v}</span>
        </div>
      ))}
    </div>
    <div className="mt-3 rounded-2xl bg-ink-2 p-3.5 text-[13px] text-haze">Notes: target GPA 3.5, research topic: NLP</div>
    <div className="mt-auto rounded-full border border-coral py-3 text-center text-[14px] font-semibold text-coral">Clear memory</div>
  </>
)

const ScreenLecture = () => (
  <>
    <div className="font-display text-[26px] font-bold leading-tight">Lecture Q&amp;A</div>
    <div className="mt-3 rounded-2xl bg-ink-2 p-3.5">
      <div className="font-mono text-[11px] uppercase text-lime">Loaded lecture</div>
      <div className="mt-1 text-[14px] font-semibold">PF Lecture 18: Static and Automatic Variables</div>
    </div>
    <div className="mt-4 flex flex-col gap-3 text-[13px] leading-snug">
      <div className="max-w-[85%] self-end rounded-2xl rounded-br-sm bg-ink-3 p-3">When does a static variable get initialised?</div>
      <div className="rounded-2xl rounded-bl-sm bg-ink-2 p-3">
        Once, before the program starts, and it keeps its value between calls.
        <div className="mt-2 rounded-lg border border-lime/40 p-2 text-[12px] text-lime">Source: lecture excerpt 3</div>
      </div>
    </div>
    <div className="mt-auto rounded-2xl border border-haze/30 p-3 text-[12px] text-haze">Privacy: instructor names and contacts are never revealed.</div>
  </>
)

const Button = ({ href, children, variant = "lime" }: { href: string; children: ReactNode; variant?: "lime" | "ghost" | "ink" }) => {
  const styles = {
    lime: "bg-lime text-ink hover:bg-white",
    ghost: "border border-haze/40 text-mist hover:border-lime hover:text-lime",
    ink: "bg-ink text-lime hover:bg-ink-3",
  }[variant]
  return (
    <a
      href={href}
      className={`inline-flex items-center justify-center rounded-full px-7 py-3.5 text-base font-semibold transition focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-lime ${styles}`}
    >
      {children}
    </a>
  )
}

/* ------------------------------- Page ------------------------------- */

export default function App() {
  return (
    <div className="h-full overflow-y-auto scroll-smooth bg-ink text-mist [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
      {/* Nav */}
      <header className="sticky top-0 z-50 border-b border-white/5 bg-ink/85 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4 md:px-10">
          <a href="#top" className="font-display text-lg font-extrabold tracking-tight">
            CAMPUSMIND<span className="text-lime"> AI</span>
          </a>
          <nav className="hidden items-center gap-8 text-sm text-haze md:flex">
            {[
              ["Problem", "#problem"],
              ["Solution", "#solution"],
              ["Features", "#features"],
              ["How it works", "#flow"],
              ["Tech", "#tech"],
            ].map(([l, h]) => (
              <a key={h} href={h} className="transition hover:text-lime">
                {l}
              </a>
            ))}
          </nav>
          <a href="#download" className="rounded-full bg-lime px-5 py-2 text-sm font-semibold text-ink transition hover:bg-white">
            Get the APK
          </a>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="relative overflow-hidden px-6 pb-24 pt-16 md:px-10 lg:pb-32 lg:pt-24">
        <div className="absolute -right-40 -top-56 h-[760px] w-[760px] rounded-full bg-ink-3" />
        <div className="absolute -bottom-72 right-20 h-[480px] w-[480px] rounded-full bg-lime" />
        <div className="absolute right-[34%] top-24 hidden h-24 w-24 rounded-full bg-coral lg:block" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-16 lg:grid-cols-[1.15fr_1fr]">
          <div>
            <Eyebrow>
              {INFO.hackathon} · {INFO.date}
            </Eyebrow>
            <h1 className="mt-8 font-display text-[clamp(3.5rem,11vw,8.5rem)] font-extrabold leading-[0.88] tracking-[-0.05em]">
              CAMPUS
              <br />
              MIND<span className="text-lime"> AI</span>
            </h1>
            <p className="mt-8 max-w-xl text-xl leading-relaxed text-haze md:text-2xl">{INFO.tagline}</p>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-haze/80">{INFO.intro}</p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Button href="#download">Download the APK</Button>
              <Button href="#flow" variant="ghost">
                See how it works
              </Button>
            </div>
          </div>
          <div className="flex justify-center">
            <Phone tilt={5}>
              <ScreenPersonas />
            </Phone>
          </div>
        </div>
      </section>

      {/* Problem */}
      <Section id="problem" className="bg-ink-2">
        <Eyebrow>The problem</Eyebrow>
        <H className="mt-6 max-w-4xl">{INFO.problem.headline}</H>
        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {INFO.problem.stats.map((s, i) => (
            <div key={i} className="rounded-3xl bg-ink p-8 md:p-10">
              <div className={`font-display text-[clamp(2.5rem,5vw,3.5rem)] font-extrabold leading-none tracking-[-0.04em] ${i === 1 ? "text-coral" : "text-lime"}`}>{s.n}</div>
              <p className="mt-5 text-xl leading-snug">{s.t}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Solution */}
      <Section id="solution">
        <div className="grid items-center gap-16 lg:grid-cols-[1.2fr_1fr]">
          <div>
            <Eyebrow>The solution</Eyebrow>
            <H className="mt-6">{INFO.solution.headline}</H>
            <p className="mt-8 max-w-2xl text-xl leading-relaxed text-haze">{INFO.solution.body}</p>
            <ul className="mt-10 flex flex-col gap-5">
              {INFO.solution.points.map((p) => (
                <li key={p} className="flex items-center gap-4 text-xl">
                  <span className="h-3.5 w-3.5 shrink-0 rounded-full bg-lime" />
                  {p}
                </li>
              ))}
            </ul>
          </div>
          <div className="flex justify-center">
            <Phone tilt={-4}>
              <ScreenChat />
            </Phone>
          </div>
        </div>
      </Section>

      {/* Features */}
      <Section id="features" className="bg-ink-2">
        <Eyebrow>Key features</Eyebrow>
        <H className="mt-6">Everything a student needs, in one app.</H>
        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {INFO.features.map((f, i) => (
            <div
              key={f.k}
              className={`flex gap-6 rounded-3xl p-8 transition hover:-translate-y-1 md:p-10 ${i === 0 ? "bg-lime text-ink" : "bg-ink"}`}
            >
              <div className={`font-mono text-lg ${i === 0 ? "text-ink" : "text-lime"}`}>{f.k}</div>
              <div>
                <h3 className="font-display text-3xl font-bold leading-tight">{f.t}</h3>
                <p className={`mt-3 text-lg leading-snug ${i === 0 ? "text-ink/80" : "text-haze"}`}>{f.d}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {INFO.personas.map(([t, d]) => (
            <div key={t} className="rounded-2xl border border-haze/25 p-5">
              <div className="font-display text-lg font-bold text-lime">{t}</div>
              <p className="mt-1 text-sm leading-snug text-haze">{d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Flow */}
      <Section id="flow">
        <Eyebrow>User flow</Eyebrow>
        <H className="mt-6 max-w-3xl">From persona to grounded answer in four steps.</H>
        <div className="mt-16 grid justify-items-center gap-14 md:grid-cols-2 xl:grid-cols-4 xl:gap-6">
          {[
            { c: <ScreenPersonas />, l: "1 · Pick a persona" },
            { c: <ScreenChat />, l: "2 · Ask anything" },
            { c: <ScreenMemory />, l: "3 · It remembers you" },
            { c: <ScreenLecture />, l: "4 · Ground in lectures" },
          ].map((s, i) => (
            <div key={i} className={i % 2 ? "xl:mt-12" : ""}>
              <Phone label={s.l}>{s.c}</Phone>
            </div>
          ))}
        </div>
      </Section>

      {/* Tech */}
      <Section id="tech" className="bg-ink-2">
        <Eyebrow>Technical highlights</Eyebrow>
        <H className="mt-6 max-w-3xl">Native Android, built to be trusted.</H>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {INFO.stack.map((s) => (
            <div key={s.g} className="rounded-3xl border border-haze/25 p-7">
              <div className="font-mono text-sm uppercase tracking-widest text-lime">{s.g}</div>
              <div className="mt-6 flex flex-col gap-3">
                {s.i.map((x) => (
                  <div key={x} className="rounded-xl bg-ink px-4 py-3 font-mono text-sm leading-snug">
                    {x}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 flex items-start gap-4 rounded-3xl bg-ink-3 p-8 text-lg">
          <span className="mt-2 h-3 w-3 shrink-0 rounded-full bg-coral" />
          {INFO.differentiator}
        </div>
      </Section>

      {/* Team */}
      <Section id="team">
        <Eyebrow>The team</Eyebrow>
        <H className="mt-6">{INFO.team}</H>
        <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {INFO.members.map((m, i) => (
            <div key={m} className="rounded-3xl bg-ink-2 p-7">
              <div className={`flex h-14 w-14 items-center justify-center rounded-full font-display text-xl font-bold text-ink ${["bg-lime", "bg-coral", "bg-haze", "bg-lime"][i]}`}>
                {m.split(" ").filter((w) => /^[A-Z]/.test(w)).slice(0, 2).map((w) => w[0]).join("")}
              </div>
              <div className="mt-5 text-lg font-semibold leading-snug">{m}</div>
            </div>
          ))}
        </div>
      </Section>

      {/* CTA */}
      <section id="download" className="relative overflow-hidden bg-lime px-6 py-24 text-ink md:px-10 lg:py-32">
        <div className="absolute -bottom-72 -right-40 h-[620px] w-[620px] rounded-full bg-ink" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-14 lg:grid-cols-[1.3fr_1fr]">
          <div>
            <Eyebrow dark>Try the APK</Eyebrow>
            <h2 className="mt-6 font-display text-[clamp(3rem,8vw,6.5rem)] font-extrabold leading-[0.95] tracking-[-0.04em]">{INFO.cta.headline}</h2>
            <ol className="mt-10 flex flex-col gap-4">
              {INFO.cta.steps.map((s, i) => (
                <li key={s} className="flex items-center gap-4 text-lg font-medium">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink font-mono text-lime">{i + 1}</span>
                  {s}
                </li>
              ))}
            </ol>
            <div className="mt-10 flex flex-wrap items-center gap-5">
              <Button href={INFO.cta.link} variant="ink">
                Download APK
              </Button>
              <span className="font-mono text-sm">{INFO.cta.contact}</span>
            </div>
          </div>
          <div className="flex flex-col items-center gap-4">
            <div className="grid h-[280px] w-[280px] place-items-center rounded-[32px] bg-mist shadow-2xl">
              <div className="grid grid-cols-5 gap-1.5">
                {Array.from({ length: 25 }).map((_, i) => (
                  <div key={i} className={`h-9 w-9 rounded ${[0, 1, 3, 4, 5, 9, 12, 15, 19, 20, 21, 23, 24, 7, 17].includes(i) ? "bg-ink" : "bg-ink/10"}`} />
                ))}
              </div>
            </div>
            <div className="font-mono text-sm text-mist">[Replace with APK QR code]</div>
          </div>
        </div>
      </section>

      <footer className="flex flex-col items-center justify-between gap-2 px-6 py-8 font-mono text-sm text-haze md:flex-row md:px-10">
        <span>{INFO.app}</span>
        <span>
          {INFO.hackathon} · {INFO.date}
        </span>
      </footer>
    </div>
  )
}
